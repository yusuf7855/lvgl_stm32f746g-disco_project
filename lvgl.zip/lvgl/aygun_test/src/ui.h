// SquareLine LVGL GENERATED FILE
// EDITOR VERSION: SquareLine Studio 1.2.0
// LVGL VERSION: 8.3.4
// PROJECT: SquareLine_Project

#ifndef _SQUARELINE_PROJECT_UI_H
#define _SQUARELINE_PROJECT_UI_H

#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl/lvgl.h"

extern lv_obj_t * ui_Screen3;
void ui_event_Button3(lv_event_t * e);
extern lv_obj_t * ui_Button3;
void ui_event_Button4(lv_event_t * e);
extern lv_obj_t * ui_Button4;
void ui_event_Button5(lv_event_t * e);
extern lv_obj_t * ui_Button5;
extern lv_obj_t * ui_Image3;
void ui_event_Slider3(lv_event_t * e);
extern lv_obj_t * ui_Slider3;
extern lv_obj_t * ui_YUZDE2;
void ui_event_Switch1(lv_event_t * e);
extern lv_obj_t * ui_Switch1;
extern lv_obj_t * ui_Screen2;
void ui_event_Button8(lv_event_t * e);
extern lv_obj_t * ui_Button8;
void ui_event_Button7(lv_event_t * e);
extern lv_obj_t * ui_Button7;
void ui_event_Button6(lv_event_t * e);
extern lv_obj_t * ui_Button6;
void ui_event_Button9(lv_event_t * e);
extern lv_obj_t * ui_Button9;
void ui_event_Button1(lv_event_t * e);
extern lv_obj_t * ui_Button1;
extern lv_obj_t * ui_Image2;
void ui_event_Arc1(lv_event_t * e);
extern lv_obj_t * ui_Arc1;
extern lv_obj_t * ui_PARLAKLIK;
void ui_event_Switch2(lv_event_t * e);
extern lv_obj_t * ui_Switch2;
void ui_event_Slider2(lv_event_t * e);
extern lv_obj_t * ui_Slider2;
extern lv_obj_t * ui_YUZDE;
void ui_event_Slider1(lv_event_t * e);
extern lv_obj_t * ui_Slider1;
void ui_event_YUZDE1(lv_event_t * e);
extern lv_obj_t * ui_YUZDE1;
extern lv_obj_t * ui_Screen1;
void ui_event_Button10(lv_event_t * e);
extern lv_obj_t * ui_Button10;
extern lv_obj_t * ui_Image1;


LV_IMG_DECLARE(ui_img_screen3_png);    // assets\screen3.png
LV_IMG_DECLARE(ui_img_screen3sonnnn_png);    // assets\screen3sonnnn.png
LV_IMG_DECLARE(ui_img_screen1yeni_png);    // assets\screen1yeni.png




void ui_init(void);

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif
